//counter 
$('.amount').countUp({
  'time': 1500,
  'delay': 5
});