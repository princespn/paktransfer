<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('import-css'); ?>
    <link href="<?php echo e(asset('assets/admin/css/bootstrap-fileinput.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--Dashboard area-->
    <section class="section-padding gray-bg">
        <div class="container">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-content">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="dashboard-inner-content">
                                    <div class="card bg-white">
                                        <div class="card-header">
                                            <h3 class="card-title"><?php echo e(__($page_title)); ?></h3>
                                        </div>
                                        <div class="card-body">
                                            <form action="" method="post" name="editForm" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>

                                                <div class="row justify-content-end">
                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('First Name'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="firstname" value="<?php echo e($user->firstname); ?>" placeholder="<?php echo app('translator')->get('First Name'); ?>" >
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Last Name'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="lastname" value="<?php echo e($user->lastname); ?>" placeholder="<?php echo app('translator')->get('Last Name'); ?>" >
                                                    </div>

                                                    <?php if($user->merchant == 2): ?>
                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Company Name'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="company_name" value="<?php echo e($user->company_name); ?>" placeholder="<?php echo app('translator')->get('Company Name'); ?>" >
                                                    </div>
                                                    <?php endif; ?>


                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Email Address'); ?></label>
                                                        <input type="email"  class="form-control form-control-lg" name="email" value="<?php echo e($user->email); ?>" placeholder="<?php echo app('translator')->get('Email Address'); ?>" disabled>
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Contact Number'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="mobile" value="<?php echo e($user->mobile); ?>" placeholder="<?php echo app('translator')->get('Contact Number'); ?>" disabled>
                                                    </div>



                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Address'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="address" value="<?php echo e($user->address->address); ?>" placeholder="<?php echo app('translator')->get('Address'); ?>" >
                                                    </div>

                                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('State'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="state" value="<?php echo e($user->address->state); ?>" placeholder="<?php echo app('translator')->get('State'); ?>" >
                                                    </div>

                                                    <div class=" <?php if($user->merchant == 2): ?> col-xl-6 col-lg-6 col-md-6  <?php else: ?>  col-xl-4 col-lg-4 col-md-4  <?php endif; ?> col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Zip'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="zip" value="<?php echo e($user->address->zip); ?>" placeholder="<?php echo app('translator')->get('Zip'); ?>" >
                                                    </div>

                                                    <div class="<?php if($user->merchant == 2): ?> col-xl-6 col-lg-6 col-md-6  <?php else: ?>  col-xl-4 col-lg-4 col-md-4  <?php endif; ?> col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('City'); ?></label>
                                                        <input type="text"  class="form-control form-control-lg" name="city" value="<?php echo e($user->address->city); ?>" placeholder="<?php echo app('translator')->get('City'); ?>" >
                                                    </div>



                                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                                        <label for="currency"><?php echo app('translator')->get('Country'); ?></label>
                                                        <select class="form-control form-control-lg" name="country">
                                                            <?php echo $__env->make('partials.country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                                        <div class="form-group">
                                                            <div class="fileinput fileinput-new " data-provides="fileinput">
                                                                <div class="fileinput-new thumbnail" style="width: 200px; height: 150px;"
                                                                     data-trigger="fileinput">
                                                                    <img  src="<?php echo e(get_image(config('constants.user.profile.path') .'/'. $user->image)); ?>" alt="...">

                                                                </div>
                                                                <div class="fileinput-preview fileinput-exists thumbnail"
                                                                     style="max-width: 200px; max-height: 150px"></div>

                                                                <div class="img-input-div">
                                                                    <span class="btn btn-info btn-file">
                                                                        <span class="fileinput-new "> <?php echo app('translator')->get('Select image'); ?></span>
                                                                        <span class="fileinput-exists"> <?php echo app('translator')->get('Change'); ?></span>
                                                                        <input type="file" name="image" accept="image/*">
                                                                    </span>
                                                                    <a href="#" class="btn btn-danger fileinput-exists"
                                                                       data-dismiss="fileinput"> <?php echo app('translator')->get('Remove'); ?></a>
                                                                </div>

                                                                <code><?php echo app('translator')->get('Image size 800*800'); ?></code>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-6">
                                                        <button type="submit" class="custom-btn"><?php echo app('translator')->get('Update Profile'); ?></button>
                                                    </div>
                                                </div>
                                            </form>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section><!--/Dashboard area-->

    <script>
        document.forms['editForm'].elements['country'].value = "<?php echo e($user->address->country); ?>"
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('import-js'); ?>
    <script src="<?php echo e(asset('assets/admin/js/bootstrap-fileinput.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/edit-profile.blade.php ENDPATH**/ ?>