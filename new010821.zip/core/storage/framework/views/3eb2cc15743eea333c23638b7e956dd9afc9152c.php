<?php $__env->startSection('content'); ?>

    <!--Hero Area-->
    <section class="hero-section">
        <div class="hero-area wave-animation">
            <div class="single-hero gradient-overlay">
                <div id="particles-js"></div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-8 centered">
                            <div class="hero-sub">
                                <div class="table-cell">
                                    <div class="hero-left">
                                        <?php if($general->reg == 0): ?>

                                            <h3><?php echo e(__($page_title)); ?> <?php echo app('translator')->get("Has been Deactivated By Admin"); ?></h3>
                                        <?php else: ?>

                                        <h2><?php echo e(__($page_title)); ?></h2>
                                        <div class="account-form">
                                            <form class="row" action="<?php echo e(route('user.register')); ?>" method="post" id="recaptchaForm">
                                                <?php echo csrf_field(); ?>
                                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                    <input type="text" name="firstname" value="<?php echo e(old('firstname')); ?>" placeholder="<?php echo app('translator')->get('First Name'); ?>" required>
                                                </div>

                                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                    <input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>" placeholder="<?php echo app('translator')->get('Last Name'); ?>" required>
                                                </div>


                                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                    <input type="text" name="username" value="<?php echo e(old('username')); ?>" placeholder="<?php echo app('translator')->get('Username'); ?>" required>
                                                </div>

                                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                    <input type="email" name="email" value="<?php echo e(old('email')); ?>"  placeholder="<?php echo app('translator')->get('Enter Your E-mail'); ?>" required>
                                                </div>


                                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                    <input type="text" id="mobile"  name="mobile"  value="<?php echo e(old('mobile')); ?>"  placeholder="<?php echo app('translator')->get('Enter Your Mobile No.'); ?>"  required>
                                                </div>


                                                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                                    <select name="country" id="country" required>
                                                        <?php echo $__env->make('partials.country', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                    </select>
                                                </div>



                                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                                    <input type="password" name="password" placeholder="<?php echo app('translator')->get('Enter Your Password'); ?>" required>
                                                </div>
                                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                                    <input type="password" name="password_confirmation" placeholder="<?php echo app('translator')->get('Re-type Password'); ?>" required>
                                                </div>




                                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                                    <button type="submit" id="recaptcha" class="bttn-mid btn-fill w-100"><?php echo app('translator')->get('Create account'); ?></button>
                                                </div>
                                            </form>
                                            <div class="extra-links">
                                                <a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login account'); ?></a>

                                            </div>
                                        </div>
                                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Hero Area-->



    <?php if($plugins[2]->status == 1): ?>
        <script src="//code.jquery.com/jquery-3.4.1.min.js"></script>
        <?php echo recaptcha() ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/auth/register.blade.php ENDPATH**/ ?>