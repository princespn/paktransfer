<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="icon" href="<?php echo e(get_image(config('constants.logoIcon.path') .'/favicon.png')); ?>" type="image/x-icon">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(get_image(config('constants.logoIcon.path') .'/favicon.png')); ?>"/>
    <title><?php echo e($general->sitename); ?> | <?php echo e(($page_title) ? $page_title : ''); ?> </title>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('assets/template/basic/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('import-css'); ?>

    <?php echo $__env->yieldPushContent('style-lib'); ?>

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"/>
    <link href="<?php echo e(asset('assets/template/basic/css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/template/basic/css/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/template/basic/css/nice-select.css')); ?>" rel="stylesheet">
    <?php echo $__env->make('partials.notify-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Main css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/basic/css/style.php')); ?>?color=<?php echo e($general->bclr); ?>">
    <?php echo $__env->yieldContent('style'); ?>

    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->


</head>
<body>
<!--nav-->
<section class="header-area-2">
    <nav class="navbar navbar-expand-xl dashboard-menu">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(get_image(config('constants.logoIcon.path') .'/logo.png')); ?>" class="d-inline-block align-top" alt=""></a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item <?php echo e(isActive('user.home') ? 'active': ''); ?>"><a class="nav-link" href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a></li>
                    <li class="nav-item <?php echo e(isActive('user.transaction') ? 'active': ''); ?>"><a class="nav-link" href="<?php echo e(route('user.transaction')); ?>"><?php echo app('translator')->get('Transaction'); ?></a></li>

                    <?php if($general->mt_status == 1): ?>
                    <li class="nav-item <?php echo e(isActive('user.moneyTransfer') ? 'active': ''); ?> "><a class="nav-link" href="<?php echo e(route('user.moneyTransfer')); ?>"><?php echo app('translator')->get('Send'); ?></a></li>
                    <?php endif; ?>

                    <?php if($general->exm_status == 1): ?>
                    <li class="nav-item <?php echo e(isActive('user.exchange') ? 'active': ''); ?>"><a class="nav-link" href="<?php echo e(route('user.exchange')); ?>"><?php echo app('translator')->get('Exchange'); ?></a></li>
                    <?php endif; ?>






                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo app('translator')->get('Deposit'); ?></a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('user.deposit')); ?>"><?php echo app('translator')->get('Deposit Money'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.depositLog')); ?>"><?php echo app('translator')->get('Deposit Log'); ?></a></li>
                        </ul>
                    </li>


                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo app('translator')->get('Withdraw'); ?></a>
                        <ul class="dropdown-menu">
                            <?php if($general->withdraw_status == 1): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.withdraw.money')); ?>"><?php echo app('translator')->get('Withdraw Money'); ?></a></li>
                            <?php endif; ?>

                            <li><a class="dropdown-item" href="<?php echo e(route('user.withdrawLog')); ?>"><?php echo app('translator')->get('Withdraw Log'); ?></a></li>
                        </ul>
                    </li>



                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Hi, <?php echo e(Auth::user()->username); ?></a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route('user.edit-profile')); ?>"><?php echo app('translator')->get('Edit Profile'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.change-password')); ?>"><?php echo app('translator')->get('Change Password'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.ticket')); ?>"><?php echo app('translator')->get('Support'); ?></a></li>

                            <li><a class="dropdown-item" href="<?php echo e(route('user.api-key')); ?>"><?php echo app('translator')->get('API KEY'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.twoFA')); ?>"><?php echo app('translator')->get('2FA Security'); ?></a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.loginHistory')); ?>"><?php echo app('translator')->get('Login History'); ?></a></li>
                        </ul>
                    </li>
                </ul>
                <div class="header-btn justify-content-end">
                    <a href="<?php echo e(route('user.logout')); ?>" class="bttn-small btn-emt"><?php echo app('translator')->get('Logout'); ?></a>
                </div>
            </div>
        </div>
    </nav>
</section><!--/nav-->

<?php echo $__env->make('templates.basic.partials.user-breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>




<?php echo $__env->make(activeTemplate().'partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('assets/template/basic/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/jquery-migrate.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/bootstrap.min.js')); ?>"></script>
<?php echo $__env->yieldContent('import-js'); ?>

<script src="<?php echo e(asset('assets/template/basic/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/parallax.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/template/basic/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/scrollUp.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/jquery.nice-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/particles.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/particle-app.js')); ?>"></script>

<?php echo $__env->make('partials.notify-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<script src="<?php echo e(asset('assets/template/basic/js/script.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>

<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/layouts/user.blade.php ENDPATH**/ ?>