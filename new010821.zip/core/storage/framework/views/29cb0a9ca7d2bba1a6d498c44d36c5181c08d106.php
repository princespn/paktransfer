<?php $__env->startSection('panel'); ?>

    <div class="row">

        <div class="col-lg-12">
            <div class="card">

                <div class="card-body">


                    <div class="row mt-4">
                        <div class="col-xl-4">
                            <div class="card">
                                <div class="card-header bg-primary">
                                    <h4 class="card-title font-weight-normal">Money Transfer Charge</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.transaction-fees.update')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Percent Charge</label>
                                            <div class="col-sm-12">
                                                <div class="input-group ">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="transfer_percent_charge" value="<?php echo e($moneyTransfer->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Fix Charge</label>
                                            <div class="col-sm-12">
                                                <div class="input-group ">
                                                    <input type="text" class="form-control" placeholder="Fix Charge" name="transfer_fix_charge" value="<?php echo e($moneyTransfer->fix_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Minimum Transfer</label>
                                            <div class="col-sm-12">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Minimum Transfer" name="minimum_transfer" value="<?php echo e($moneyTransfer->minimum_transfer); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Maximum Transfer</label>
                                            <div class="col-sm-12">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Maximum Transfer" name="maximum_transfer" value="<?php echo e($moneyTransfer->maximum_transfer); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <button type="submit"  name="sbtn" value="1" class="btn btn-primary mr-2 btn-block">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>






                        <div class="col-xl-4">
                            <div class="card">
                                <div class="card-header bg-primary">
                                    <h4 class="card-title font-weight-normal">Request Money Charge</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.transaction-fees.update')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Percent Charge</label>
                                            <div class="col-sm-12">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="request_money_percent_charge" value="<?php echo e($request_money->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Fix Charge</label>
                                            <div class="col-sm-12">
                                                <div class="input-group ">
                                                    <input type="text" class="form-control" placeholder="Fix Charge" name="request_money_fix_charge" value="<?php echo e($request_money->fix_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Minimum Transfer</label>
                                            <div class="col-sm-12">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Minimum Transfer" name="request_money_minimum_transfer" value="<?php echo e($request_money->minimum_transfer); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">Maximum Transfer</label>
                                            <div class="col-sm-12">
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Maximum Transfer" name="request_money_maximum_transfer" value="<?php echo e($request_money->maximum_transfer); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>




                                        <div class="form-group">
                                            <button type="submit"  name="sbtn" value="3" class="btn btn-primary mr-2 btn-block">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>







                        <div class="col-xl-4">
                            <div class="card">
                                <div class="card-header bg-primary">
                                    <h4 class="card-title font-weight-normal">Voucher Charge</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.transaction-fees.update')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">New Voucher Percent Charge</label>
                                            <div class="col-sm-12">
                                                <div class="input-group ">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="new_voucher_percent_charge" value="<?php echo e($newVoucher->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">New Voucher Fix Charge</label>
                                            <div class="col-sm-12">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Fix Charge" name="new_voucher_fix_charge" value="<?php echo e($newVoucher->fix_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group row">
                                            <label class="col-sm-12 col-form-label">New Voucher Minimum Amount</label>
                                            <div class="col-sm-12">
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Minimum Amount" name="new_voucher_minimum_amount" value="<?php echo e($newVoucher->minimum_amount); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class=" row">
                                            <div class="form-group col-sm-6">

                                                <label class=" col-form-label">Active Voucher Percent Charge</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="active_voucher_percent_charge" value="<?php echo e($activeVoucher->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="form-group col-sm-6">

                                                <label class="col-form-label">Active Voucher Fix Charge</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Fix Charge" name="active_voucher_fix_charge" value="<?php echo e($activeVoucher->fix_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group">
                                            <button type="submit"  name="sbtn" value="5" class="btn btn-primary mr-2 btn-block mt-3">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>


                        <div class="col-xl-4">


                            <div class="card">
                                <div class="card-header bg-primary">
                                    <h4 class="card-title font-weight-normal">Invoice Charge</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.transaction-fees.update')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group row">
                                            <div class="col-sm-6">

                                                <label class="col-form-label">Percent Charge</label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="invoice_percent_charge" value="<?php echo e($invoice->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">

                                                <label class=" col-form-label">Fix Charge</label>
                                                <div class="input-group mb-1">
                                                    <input type="text" class="form-control" placeholder="Fix Charge" name="invoice_fix_charge" value="<?php echo e($invoice->fix_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="form-group ">
                                            <button type="submit"  name="sbtn" value="4" class="btn btn-primary mr-2 btn-block mt-4">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4">
                            <div class="card">
                                <div class="card-header bg-primary">
                                    <h4 class="card-title font-weight-normal">Money Exchange Charge</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.transaction-fees.update')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group row">
                                            <div class="col-sm-12">

                                                <label class="col-form-label">Percent Charge</label>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="exchange_percent_charge" value="<?php echo e($money_exchange->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit"  name="sbtn" value="2" class="btn btn-primary mr-2 btn-block">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-4">
                            <div class="card">
                                <div class="card-header bg-primary">
                                    <h4 class="card-title font-weight-normal">API Charge</h4>
                                </div>
                                <div class="card-body">
                                    <form action="<?php echo e(route('admin.transaction-fees.update')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group row">
                                            <div class="col-sm-6">
                                                <label class="col-form-label">Percent Charge</label>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Percent Charge" name="api_percent_charge" value="<?php echo e($api_charge->percent_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text">%</span>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-sm-6">
                                                <label class="col-form-label">Fix Charge</label>
                                                <div class="input-group mb-3">
                                                    <input type="text" class="form-control" placeholder="Fix Charge" name="api_fix_charge" value="<?php echo e($api_charge->fix_charge); ?>" />
                                                    <div class="input-group-append">
                                                        <span class="input-group-text"><?php echo e($general->cur_text); ?></span>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="form-group">
                                            <button type="submit"  name="sbtn" value="6" class="btn btn-primary mr-2 btn-block">Update</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>





                    </div>





                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script-lib'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .sp-replacer {
            padding: 0;
            border: 1px solid rgba(0, 0, 0, .125);
            border-radius: 5px 0 0 5px;
            border-right: none;
        }

        .sp-preview {
            width: 100px;
            height: 44px;
            border: 0;
        }

        .sp-preview-inner {
            width: 110px;
        }

        .sp-dd {
            display: none;
        }

        .input-group > .form-control:not(:first-child) {
            border-top-left-radius: 0 !important;
            border-bottom-left-radius: 0 !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/admin/setting/transaction_fees.blade.php ENDPATH**/ ?>