<?php $__env->startSection('title','SMS verification form'); ?>
<?php $__env->startSection('content'); ?>

<!--Hero Area-->
<section class="hero-section">
    <div class="hero-area wave-animation">
        <div class="single-hero gradient-overlay">
            <div id="particles-js"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 centered">
                        <div class="hero-sub">
                            <div class="table-cell">
                                <div class="hero-left">
                                    <h2><?php echo app('translator')->get('Forgot Password'); ?></h2>
                                    <div class="account-form">
                                        <form action="<?php echo e(route('user.password.email')); ?>" method="post" class="row">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-xl-12 col-lg-12">
                                                <label class="text-white"><?php echo app('translator')->get('Email Address'); ?></label>
                                                <input type="email" name="email" placeholder="<?php echo app('translator')->get('Your E-mail Address'); ?>"  required>
                                            </div>
                                            <button type="submit" class="bttn-mid btn-fill w-100"> <?php echo app('translator')->get('Submit'); ?></button>
                                        </form>
                                        <div class="extra-links">
                                            <a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Back To Login'); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><!--/Hero Area-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/auth/passwords/email.blade.php ENDPATH**/ ?>