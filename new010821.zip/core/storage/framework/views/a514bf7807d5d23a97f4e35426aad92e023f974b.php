<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>

    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-content">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="dashboard-inner-content">

                                    <div class="card bg-white">
                                        <div class="card-header">

                                            <h5 class="card-title"><?php echo app('translator')->get('My'); ?> <?php echo e(__($page_title)); ?></h5>
                                            <a href="<?php echo e(route('user.ticket')); ?>" class="bttn-small btn-emt"><?php echo app('translator')->get('My Support Ticket'); ?></a>
                                        </div>


                                        <div class="card-body">
                                            <form  action="<?php echo e(route('user.ticket.store')); ?>" role="form" method="post" enctype="multipart/form-data" id="recaptchaForm">
                                                <?php echo e(csrf_field()); ?>

                                                <div class="row mt-5">

                                                    <div class="form-group col-md-6">
                                                        <label for="name"><?php echo app('translator')->get('Name'); ?></label>
                                                        <input type="text"  name="name" value="<?php echo e($user->firstname . ' '.$user->lastname); ?>" class="form-control" placeholder="<?php echo app('translator')->get('Enter Name'); ?>" required>
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label for="email"><?php echo app('translator')->get('Email address'); ?></label>
                                                        <input type="email"  name="email" value="<?php echo e($user->email); ?>" class="form-control " placeholder="<?php echo app('translator')->get('Enter your Email'); ?>" required>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="form-group col-md-12">
                                                        <label for="website"><?php echo app('translator')->get('Subject'); ?></label>
                                                        <input type="text" name="subject" value="<?php echo e(old('subject')); ?>" class="form-control " placeholder="<?php echo app('translator')->get('Subject'); ?>" >
                                                    </div>

                                                </div>


                                                <div class="row">
                                                    <div class="form-group col-md-6">
                                                        <label for="hep"><?php echo app('translator')->get('Department'); ?></label>
                                                        <select class="form-control required" name="department" required>
                                                            <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($topic->id); ?>"><?php echo e($topic->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>

                                                    <div class="form-group col-md-6">
                                                        <label for="hep"><?php echo app('translator')->get('Priority'); ?></label>
                                                        <select class="form-control required" name="priority" required>
                                                            <option value="medium"><?php echo app('translator')->get('Medium'); ?></option>
                                                            <option value="high"><?php echo app('translator')->get('High'); ?></option>
                                                            <option value="low"><?php echo app('translator')->get('Low'); ?></option>
                                                        </select>
                                                    </div>
                                                </div>


                                                <div class="row">
                                                    <div class="col-12 form-group">
                                                        <label for="inputMessage"><?php echo app('translator')->get('Message'); ?></label>
                                                        <textarea name="message" id="inputMessage" rows="12" class="form-control"><?php echo e(old('message')); ?></textarea>
                                                    </div>
                                                </div>


                                                <div class="row form-group">
                                                    <div class="col-sm-12">
                                                        <label for="inputAttachments"><?php echo app('translator')->get('Attachments'); ?></label>
                                                    </div>
                                                    <div class="col-sm-9 file-upload">
                                                        <input type="file" name="attachments[]" id="inputAttachments" class="form-control" />
                                                        <div id="fileUploadsContainer"></div>

                                                    </div>



                                                    <div class="col-sm-3">
                                                        <button type="button" class="btn btn-primary btn-block" onclick="extraTicketAttachment()">
                                                            <i class="fa fa-plus"></i> <?php echo app('translator')->get('Add More'); ?>
                                                        </button>
                                                    </div>
                                                    <div class="col-xs-12 ticket-attachments-message text-muted">
                                                        <?php echo app('translator')->get("Allowed File Extensions: .jpg, .jpeg, .png, .pdf, .doc, .docx"); ?>
                                                    </div>
                                                </div>



                                                <div class="row form-group justify-content-center">
                                                    <div class="col-12 text-center">

                                                        <button class=" btn btn-success " type="submit" id="recaptcha" ><i class="fa fa-paper-plane"></i>&nbsp;<?php echo app('translator')->get('Submit Now'); ?></button>
                                                        <button class=" btn btn-danger  " type="button" onclick="formReset()">&nbsp;<?php echo app('translator')->get('Cancel'); ?></button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>



    <?php if($plugins[2]->status == 1): ?>
        <script src="//code.jquery.com/jquery-3.4.1.min.js"></script>
        <?php echo recaptcha() ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>
        function extraTicketAttachment() {
            $("#fileUploadsContainer").append('<input type="file" name="attachments[]" class="form-control mt-1" required />')
        }

        function formReset() {
            window.location.href = "<?php echo e(url()->current()); ?>"
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/support/sendSupportTicket.blade.php ENDPATH**/ ?>