<?php $__env->startSection('content'); ?>

    <!--Dashboard area-->
    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row dashboard-content">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-inner-content">

                        <div class="row justify-content-center">
                            <div class="col-lg-8 col-md-8 mb-4">
                                <div class="card bg-white text-center">
                                    <div class="card-header"><?php echo app('translator')->get('Payment Preview'); ?></div>
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="col-md-4">
                                                <img src="<?php echo e(get_image(config('constants.deposit.gateway.path') .'/'. $deposit->gateway->image)); ?>" style="width:100%;"/>
                                            </div>
                                            <div class="col-md-8">
                                                <h3 class="mt-3 mb-3 "><?php echo app('translator')->get('Please Pay'); ?> <span class="text-success"><?php echo e($deposit->final_amo); ?> <?php echo e($deposit->method_currency); ?></span></h3>
                                                <h3 class="mt-3 mb-3 "><?php echo app('translator')->get('To Get'); ?> <span class="text-success"><?php echo e(formatter_money($deposit->wallet_amount)); ?>  <?php echo e($deposit->currency->code); ?></span></h3>

                                                <button type="button" class="custom-btn mt-5 mb-0" id="btn-confirm" onClick="payWithRave()"><?php echo app('translator')->get('Pay Now'); ?></button>

                                                <script src="https://api.ravepay.co/flwv3-pug/getpaidx/api/flwpbf-inline.js"></script>
                                                <script>
                                                    var btn = document.querySelector("#btn-confirm");
                                                    btn.setAttribute("type", "button");
                                                    const API_publicKey = "<?php echo e($data->API_publicKey); ?>";
                                                    function payWithRave() {
                                                        var x = getpaidSetup({
                                                            PBFPubKey: API_publicKey,
                                                            customer_email: "<?php echo e($data->customer_email); ?>",
                                                            amount: "<?php echo e($data->amount); ?>",
                                                            customer_phone: "<?php echo e($data->customer_phone); ?>",
                                                            currency: "<?php echo e($data->currency); ?>",
                                                            txref: "<?php echo e($data->txref); ?>",
                                                            onclose: function() {},
                                                            callback: function(response) {
                                                                var txref = response.tx.txRef;
                                                                var status = response.tx.status;
                                                                var chargeResponse = response.tx.chargeResponseCode;
                                                                if (chargeResponse == "00" || chargeResponse == "0") {
                                                                    window.location = '<?php echo e(url('ipn/g109')); ?>/' + txref +'/'+status;
                                                                } else {
                                                                    window.location = '<?php echo e(url('ipn/g109')); ?>/' + txref+'/'+status;
                                                                }
                                                                // x.close(); // use this to close the modal immediately after payment.
                                                            }
                                                        });
                                                    }
                                                </script>
                                            </div>
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/Dashboard area-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/payment/g109.blade.php ENDPATH**/ ?>