<?php $__env->startSection('content'); ?>

    <!--Hero Area-->
    <section class="hero-section">
        <div class="hero-area wave-animation">
            <div class="single-hero gradient-overlay">
                <div id="particles-js"></div>
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-5 centered">
                            <div class="hero-sub">
                                <div class="table-cell">
                                    <div class="hero-left">
                                        <h2><?php echo e(__($page_title)); ?></h2>
                                        <div class="account-form">

                                            <form action="<?php echo e(route('user.login')); ?>" method="post" class="row" id="recaptchaForm">
                                                <?php echo csrf_field(); ?>

                                                <div class="col-xl-12">
                                                    <input type="text" name="username" placeholder="<?php echo app('translator')->get('Enter Username'); ?>" required>
                                                </div>

                                                <div class="col-xl-12">
                                                    <input type="password" name="password" placeholder="<?php echo app('translator')->get('Enter Password'); ?>">
                                                </div>

                                                <div class="col-xl-12">
                                                    <button type="submit" id="recaptcha" class="bttn-mid btn-fill w-100"><?php echo app('translator')->get('Sign In'); ?></button>
                                                </div>
                                            </form>
                                            <div class="extra-links">
                                                <a href="<?php echo e(route('user.password.request')); ?>"><?php echo app('translator')->get('Forget Password'); ?></a>
                                                <a href="<?php echo e(route('user.register')); ?>"><?php echo app('translator')->get('Register now'); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/Hero Area-->



    <?php if($plugins[2]->status == 1): ?>
        <script src="//code.jquery.com/jquery-3.4.1.min.js"></script>
        <?php echo recaptcha() ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>