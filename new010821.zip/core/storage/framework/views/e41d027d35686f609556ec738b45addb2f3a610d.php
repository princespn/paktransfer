<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-lg-12">
            <div class="card">
                <form action="<?php echo e(route('admin.frontend.bg.image.update')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">

                        <div class="form-row">

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Payment section background image</label>
                                    <div class="image-upload">
                                        <div class="thumb">
                                            <div class="avatar-preview">
                                                <div class="profilePicPreview" style="background-image: url(<?php echo e(get_image(config('constants.frontend.bgimage.path') .'/'. 'pm_bg_img.jpg')); ?>)">
                                                    <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                                </div>
                                            </div>
                                            <div class="avatar-edit">
                                                <input type="file" class="profilePicUpload" name="payment_background_image" id="profilePicUpload1" >
                                                <label for="profilePicUpload1" class="bg-primary">Upload Image</label>
                                                <small class="mt-2 text-facebook">Supported files: <b>jpg,jpeg,png,</b>. Image will be resized into <b><?php echo e(Config::get('constants.frontend.bgimage.size')); ?>px</b> </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">

                                <div class="form-group">
                                    <label>How it work section background image</label>
                                    <div class="image-upload">
                                        <div class="thumb">
                                            <div class="avatar-preview">
                                                <div class="profilePicPreview" style="background-image: url(<?php echo e(get_image(config('constants.frontend.bgimage.path') .'/'. 'work_bg_img.jpg')); ?>)">
                                                    <button type="button" class="remove-image"><i class="fa fa-times"></i></button>
                                                </div>
                                            </div>
                                            <div class="avatar-edit">
                                                <input type="file" class="profilePicUpload" name="how_it_work_background_image" id="profilePicUpload2" >
                                                <label for="profilePicUpload2" class="bg-primary">Upload Image</label>
                                                <small class="mt-2 text-facebook">Supported files: <b>jpg,jpeg,png,</b>. Image will be resized into <b><?php echo e(Config::get('constants.frontend.bgimage.size')); ?>px</b> </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="card-footer">
                        <div class="form-row justify-content-center">
                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-block btn-primary mr-2">Update</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/admin/frontend/section/bg_image.blade.php ENDPATH**/ ?>