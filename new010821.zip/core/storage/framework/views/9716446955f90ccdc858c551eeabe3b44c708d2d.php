<?php if($paginator->hasPages()): ?>
    <ul class="styled-pagination centered">
        
        <?php if($paginator->onFirstPage()): ?>
            <li class="disabled previous">
                <a href="">
                    <span class="fa fa-angle-left"></span>
                </a>
            </li>
        <?php else: ?>
            <li class="previous">
                <a href="<?php echo e($paginator->previousPageUrl()); ?>"  rel="prev"><span class="fa fa-angle-left"></span></a>
            </li>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <li class="disabled previous">
                    <a href=""><?php echo e($element); ?></a>
                </li>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="previous ">
                            <a href="#" class="active"><?php echo e($page); ?><span class="sr-only">(current)</span></a>
                        </li>
                    <?php else: ?>
                        <li class="previous">
                            <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <li class="previous"><a href="<?php echo e($paginator->nextPageUrl()); ?>"  rel="next"> <span class="fa fa-angle-right"></span></a></li>
        <?php else: ?>
            <li class="disabled">
                <a href="#" class="disabled"  aria-label="Next">
                    <span class="fa fa-angle-right"></span>
                </a>
            </li>
        <?php endif; ?>
    </ul>


<?php endif; ?>
<?php /**PATH /home/paktransfer/public_html/core/resources/views/partials/pagination.blade.php ENDPATH**/ ?>