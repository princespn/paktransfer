<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('import-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--Dashboard area-->
    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row dashboard-content">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-inner-content">

                        <div class="row">
                            <div class="col-md-12 col-sm-12">
                                <div class="card bg-white">
                                    <div class="card-header">
                                        <h4 class="card-title text-white"><?php echo app('translator')->get('Withdraw Preview'); ?></h4>
                                        <a href="<?php echo e(route('user.withdraw.money')); ?>" class="bttn-small btn-emt "><i class="fa fa-arrow-left"></i> <?php echo app('translator')->get('Another Method'); ?></a>
                                    </div>
                                    <!-- panel body -->
                                    <div class="card-body">
                                        <div class="text-center">
                                            <h3><?php echo app('translator')->get('Current Balance'); ?> : <strong><?php echo e(formatter_money($withdraw->wallet->amount)); ?>  <?php echo e($withdraw->curr->code); ?></strong></h3>
                                        </div>

                                        <div class="row mt-4 justify-content-between">
                                            <div class="col-5 myform">
                                                <div class="form-group">
                                                    <label class="control-label"><?php echo app('translator')->get('Request Amount'); ?> : </label>

                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e(formatter_money($withdraw->amount )); ?>" readonly  class="form-control form-control-lg" placeholder="<?php echo app('translator')->get('Enter Amount'); ?>">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text "><?php echo e($withdraw->curr->code); ?> </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group">
                                                    <label class="control-label"><?php echo app('translator')->get('Withdrawal Charge'); ?> : </label>
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e(formatter_money($withdraw->charge)); ?>" readonly   class="form-control form-control-lg" placeholder="<?php echo app('translator')->get('Enter Amount'); ?>">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text "><?php echo e($withdraw->currency); ?> </span>
                                                        </div>
                                                    </div>
                                                </div>




                                                <div class="form-group">
                                                    <label class=" control-label"><?php echo app('translator')->get('You Will Get'); ?> : </label>
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e(formatter_money($withdraw->final_amount)); ?>" readonly class="form-control form-control-lg" placeholder="<?php echo app('translator')->get('Enter  Amount'); ?>" required>
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text "><?php echo e($withdraw->currency); ?> </span>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="form-group">

                                                    <label class="control-label"><?php echo app('translator')->get('Available Balance'); ?> : </label>
                                                    <div class="input-group">
                                                        <input type="text" value="<?php echo e(formatter_money($withdraw->wallet->amount - $withdraw->amount)); ?>"  class="form-control form-control-lg" placeholder="<?php echo app('translator')->get('Enter Amount'); ?>" required>
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text "><?php echo e($withdraw->curr->code); ?> </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-6">
                                                <form action="<?php echo e(route('user.withdraw.submit')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                <?php $__currentLoopData = json_decode($withdraw->detail); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-group">
                                                    <label> <?php echo e(str_replace('_',' ',$k)); ?> </label>
                                                    <input type="text" name="<?php echo e($k); ?>" value="<?php echo e(old($k)); ?>"  class="form-control " placeholder="<?php echo e(str_replace('_',' ',$k)); ?>" >
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    <div class="form-group">
                                                        <button type="submit" class="custom-btn mt-4"><?php echo app('translator')->get('Confirm'); ?></button>
                                                    </div>
                                                </form>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/Dashboard area-->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/withdraw-preview.blade.php ENDPATH**/ ?>