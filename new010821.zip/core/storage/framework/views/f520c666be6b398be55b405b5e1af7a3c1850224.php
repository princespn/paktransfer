<?php $__env->startSection('content'); ?>

    <!--Dashboard area-->
    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row dashboard-content">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-inner-content">

                        <div class="row justify-content-center">
                                <div class="col-lg-12 col-md-12 mb-4">

                                    <div class="card bg-white">

                                        <div class="card-header">
                                            <h3 class="card-title"><?php echo e(__($page_title)); ?></h3>
                                        </div>


                                        <div class="card-body ">
                                            <form action="<?php echo e(route('user.manualDeposit.update')); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                            <div class="row">


                                                <div class="col-md-12">
                                                        <p class="text-center mt-2"><?php echo app('translator')->get('You have requested'); ?>  <b class="text-success"><?php echo e(formatter_money($data['amount'])); ?> <?php echo e($data['method_currency']); ?></b> <?php echo app('translator')->get(', Please pay'); ?> <b class="text-success"> <?php echo e($data['final_amo'] .' '.$data['method_currency']); ?> </b>  <?php echo app('translator')->get(' or successful payment'); ?></p>
                                                    <?php if(isset($data->gateway->description)): ?>
                                                    <h4 class="text-center mb-4"><?php echo app('translator')->get('Please follow the instruction bellow'); ?></h4>
                                                    <p class="my-4 text-center"><?php echo  @$data->gateway->description ?></p>
                                                    <?php endif; ?>
                                                    <?php if(isset($extra->delay)): ?>
                                                    <p class="text-center mt-3 font-weight-bold"><?php echo app('translator')->get('Delay'); ?>: <?php echo  @$extra->delay ?></p>
                                                    <?php endif; ?>

                                                </div>



                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="a-trans"><?php echo app('translator')->get('Verify Image'); ?></label>
                                                        <input type="file" class="form-control" name="verify_image">
                                                    </div>
                                                </div>

                                                <?php $__currentLoopData = json_decode($method->parameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label for="a-trans"><?php echo e(__($input)); ?></label>
                                                        <input type="text" class="form-control" name="ud[<?php echo e(str_slug($input)); ?>]" placeholder="<?php echo e(__($input)); ?>">
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                    <button type="submit" class="custom-btn btn-block mt-2 text-center"><?php echo app('translator')->get('Pay Now'); ?></button>
                                                    </div>
                                                </div>

                                            </div>

                                            </form>

                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/Dashboard area-->


<?php $__env->stopSection(); ?>


<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/manual_payment/manual_confirm.blade.php ENDPATH**/ ?>