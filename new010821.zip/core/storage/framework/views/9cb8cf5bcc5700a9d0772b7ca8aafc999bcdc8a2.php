<?php $__env->startSection('content'); ?>

    <!--Dashboard area-->
    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row dashboard-content">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-inner-content">

                        <div class="row justify-content-center">
                                <div class="col-lg-4 mb-4">

                                    <div class="card bg-white text-center">
                                        <div class="card-header"><?php echo app('translator')->get('Payment Preview'); ?></div>
                                        <div class="card-body ">
                                            <ul class="list-group">
                                                <li class="list-group-item" style="background-color: transparent;">
                                                    <img src="<?php echo e(get_image(config('constants.deposit.gateway.path') .'/'. $data->gateway->image)); ?>" style="max-width:100px; max-height:100px; margin:0 auto;"/>
                                                </li>
                                            </ul>
                                         </div>
                                    </div>
                                </div>

                                <div class="col-lg-8 col-md-8 mb-4">

                                    <div class="card bg-white text-center">
                                        <div class="card-header">
                                            <h5 class="card-title"><?php echo app('translator')->get('Payment Preview'); ?></h5>
                                        </div>
                                        <div class="card-body ">
                                            <ul class="list-group">

                                                <li class="list-group-item">
                                                    <?php echo app('translator')->get('Amount'); ?>: <strong><?php echo e(formatter_money($data->amount)); ?> </strong> <?php echo e($data->method_currency); ?>

                                                </li>
                                                <li class="list-group-item">
                                                    <?php echo app('translator')->get('Charge'); ?>: <strong><?php echo e(formatter_money($data->charge)); ?></strong> <?php echo e($data->baseCurrency()); ?>

                                                </li>
                                                <li class="list-group-item">
                                                    <?php echo app('translator')->get('Payable'); ?>: <strong> <?php echo e($data->final_amo); ?></strong> <?php echo e($data->baseCurrency()); ?>

                                                </li>
                                                <li class="list-group-item">
                                                    <?php echo app('translator')->get('Conversion Rate'); ?>: <strong>1 <?php echo e($data->method_currency); ?> =  <?php echo e(formatter_money($data->cur_rate * $data->gate_rate)); ?>  <?php echo e($data->currency->code); ?>  </strong>
                                                </li>

                                                <li class="list-group-item">
                                                    <?php echo app('translator')->get('You will get'); ?> <b> <?php echo e(formatter_money($data->wallet_amount)); ?>  <?php echo e($data->currency->code); ?></b> <?php echo app('translator')->get('in your wallet'); ?>
                                                </li>
                                                <?php if($data->gateway->crypto==1): ?>
                                                    <li class="list-group-item">
                                                        <?php echo app('translator')->get('Conversion with'); ?> <b> <?php echo e($data->method_currency); ?></b> <?php echo app('translator')->get('and final value will Show on next step'); ?>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                            <a href="<?php echo e(route('user.deposit.confirm')); ?>" class="custom-btn btn-block mt-2 mb-0"><?php echo app('translator')->get('Pay Now'); ?></a>
                                        </div>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/Dashboard area-->


<?php $__env->stopSection(); ?>


<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/payment/preview.blade.php ENDPATH**/ ?>