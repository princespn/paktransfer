<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>
    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-content">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="dashboard-inner-content">



                                    <div class="card bg-white">
                                        <h5 class="card-header"><?php echo app('translator')->get('My'); ?> <?php echo e(__($page_title)); ?>

                                            <a href="<?php echo e(route('user.ticket.open')); ?>" class="bttn-small btn-emt"><?php echo app('translator')->get('Open New Support Ticket'); ?></a>
                                        </h5>

                                        <div class="card-body">

                                            <div class="table-responsive table-responsive-xl table-responsive-lg table-responsive-md table-responsive-sm">
                                                <table class="table table-striped mb-0 cmn-table">
                                                    <thead class="thead-dark">
                                                    <tr>
                                                        <th scope="col"><?php echo app('translator')->get('SL'); ?></th>
                                                        <th scope="col"><?php echo app('translator')->get('Date'); ?></th>
                                                        <th scope="col"><?php echo app('translator')->get('Ticket Number'); ?></th>
                                                        <th scope="col"><?php echo app('translator')->get('Subject'); ?></th>
                                                        <th scope="col"><?php echo app('translator')->get('Status'); ?></th>
                                                        <th scope="col"><?php echo app('translator')->get('Action'); ?></th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>

                                                    <?php $__currentLoopData = $supports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $support): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td data-label="<?php echo app('translator')->get('SL'); ?>"><?php echo e(++$key); ?></td>
                                                            <td data-label="<?php echo app('translator')->get('Date'); ?>"><?php echo e($support->created_at->format('d M, Y h:i A')); ?></td>
                                                            <td data-label="<?php echo app('translator')->get('Ticket'); ?>">#<?php echo e($support->ticket); ?></td>
                                                            <td data-label="<?php echo app('translator')->get('Subject'); ?>"><?php echo e($support->subject); ?></td>
                                                            <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                                                <?php if($support->status == 0): ?>
                                                                    <span class="badge badge-primary"><?php echo app('translator')->get('Open'); ?></span>
                                                                <?php elseif($support->status == 1): ?>
                                                                    <span class="badge badge-success "> <?php echo app('translator')->get('Answered'); ?></span>
                                                                <?php elseif($support->status == 2): ?>
                                                                    <span class="badge badge-info"> <?php echo app('translator')->get('Customer Replied'); ?></span>
                                                                <?php elseif($support->status == 3): ?>
                                                                    <span class="badge badge-danger "><?php echo app('translator')->get('Closed'); ?></span>
                                                                <?php endif; ?>
                                                            </td>

                                                            <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                                                <a href="<?php echo e(route('user.message', $support->ticket)); ?>" class=" btn btn-primary btn-sm">
                                                                    <i class="mx-0 ti ti-eye"></i>
                                                                </a>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-5">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <?php echo e($supports->links('partials.pagination')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/support/supportTicket.blade.php ENDPATH**/ ?>