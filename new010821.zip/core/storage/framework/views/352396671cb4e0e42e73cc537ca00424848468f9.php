<?php $__env->startSection('title','| '.$page_title); ?>

<?php $__env->startSection('style'); ?>
    <style>
        .dashboard-content{
            height: 100vh;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="section-padding gray-bg " >
        <div class="container">
            <div class="row">

                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                    <div class="dashboard-content">

                        <div class="row ">
                            <div class="col-lg-12">
                                <div style="text-align: center; margin-top: 10%;">
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo e(asset('assets/images/logoIcon/logo.png')); ?>" alt="logo" class="invoice-logo-filter"
                                             style="max-width: 100%;">
                                    </a>
                                </div>

                                <?php if(session('error')): ?>
                                    <br><br><br><h1 class="text-center " style="color: red;"> <?php echo e(__(session('error'))); ?> </h1><br><br>
                                    <br>
                                <?php elseif(session('alert')): ?>
                                    <br><br><br><h1 class="text-center " style="color: red;"> <?php echo e(__(session('alert'))); ?> </h1><br><br>
                                    <br>
                                <?php elseif(session('success')): ?>
                                    <br><br><br><h1 class="text-center bold" style="color: green;"> <?php echo e(__(session('success'))); ?> </h1><br><br>

                                <?php else: ?>
                                    <br><br><br><h1 class="text-center" style="color: red;"><?php echo app('translator')->get('AN UNESPECTED ERROR OCCURED.'); ?> <br>
                                        <?php echo app('translator')->get('PLEASE CHECK BACK WITH API OWNER.'); ?></h1><br><br><br>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>






<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'invoicePayment.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/apiPayment/api-error.blade.php ENDPATH**/ ?>