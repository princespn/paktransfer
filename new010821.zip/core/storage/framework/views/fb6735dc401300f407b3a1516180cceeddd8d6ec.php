<?php $__env->startSection('title',"$page_title"); ?>
<?php $__env->startSection('content'); ?>



    <!--breadcrumb area-->
    <section class="breadcrumb-area fixed-head gradient-overlay">
    <div id="particles-js"></div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 centered">
                    <div class="banner-title">
                        <h2><?php echo e(__($page_title)); ?></h2>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--Content Section-->
    <section class="section-padding">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12">
                    <div class="section-title centered">
                        <h2><?php echo e(__($contact->data_values->title)); ?></h2>
                        <p><?php echo e(__($contact->data_values->short_details)); ?></p>
                    </div>
                </div>
            </div>

            <div class="row">

                                <div class="col-xl-4">
                    <div class="row mt-5 cl-white">
                        <div class="col-md-12 mb-4">
                            <div class="contact-box centered">
                                <p><?php echo  $contact->data_values->contact_details ?></p>
                            </div>
                        </div>
                        <div class="col-md-12 mb-3">
                            <div class="contact-box centered">

                                <p><?php echo  $contact->data_values->email_address ?></p>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="contact-box centered ">

                                <p><?php echo  $contact->data_values->contact_number ?></p>
                            </div>
                        </div>
                    </div>


                </div>

                
                <div class="col-xl-8">
                    <div class="contact-form">
                        <form action="" method="post">
                            <?php echo csrf_field(); ?>
                            <h4 class="mb-3"><?php echo e(__($contact->data_values->form_heading)); ?></h4>


                            <div class="row">
                                <div class="col-md-6">
                                    <input type="text" name="name" placeholder="<?php echo app('translator')->get('Your Name'); ?>" value="<?php echo e(old('name')); ?>" required>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" name="phone" placeholder="<?php echo app('translator')->get('Contact Number'); ?>" value="<?php echo e(old('phone')); ?>" required>
                                </div>
                                <div class="col-md-12">
                                    <input type="text" name="email" placeholder="<?php echo app('translator')->get('Enter Email Address'); ?>" value="<?php echo e(old('email')); ?>" required>
                                </div>
                                <div class="col-md-12">
                                    <input type="text" name="subject" placeholder="<?php echo app('translator')->get('Your Subject'); ?>" value="<?php echo e(old('subject')); ?>" required>
                                </div>
                            </div>


                            <textarea name="message"  rows="6" placeholder="<?php echo app('translator')->get('Write your message'); ?>" required><?php echo e(old('message')); ?></textarea>
                            <button type="submit" class="bttn-mid btn-fill"><?php echo app('translator')->get('Send message'); ?></button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section><!--/Content Section-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/contact.blade.php ENDPATH**/ ?>