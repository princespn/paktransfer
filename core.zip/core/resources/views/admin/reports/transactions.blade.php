@extends('admin.layouts.app')

@section('panel')
<div class="row">

    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--sm table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th>@lang('User/Agent/Merchant')</th>
                                <th>@lang('User Type')</th>
                                <th>@lang('Trx')</th>
                                <th>@lang('Transacted')</th>
                                <th>@lang('Amount')</th>
                                <th>@lang('Post Balance')</th>
                                <th>@lang('Detail')</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($transactions as $trx)
                            <tr>
                                <td data-label="@lang('User')">
                                    <span class="font-weight-bold">
                                        @if ($trx->user)
                                            {{ $trx->user->fullname }}
                                        @elseif($trx->agent)
                                            {{ $trx->agent->fullname }}
                                        @else
                                            {{ $trx->merchant->fullname }}
                                        @endif
                                    </span>
                                    <br>
                                        @if ($trx->user)
                                        <span class="small"> <a href="{{ route('admin.users.detail', $trx->user_id) }}"><span>@</span>{{ $trx->user->username }}</a> </span>
                                        @elseif($trx->agent)
                                        <span class="small"> <a href="{{ route('admin.agent.detail', $trx->user_id) }}"><span>@</span>{{ $trx->agent->username }}</a> </span>
                                        @else
                                        <span class="small"> <a href="{{ route('admin.merchant.detail', $trx->user_id) }}"><span>@</span>{{ $trx->merchant->username }}</a> </span>
                                        @endif

                                </td>

                                <td data-label="@lang('User Type')">
                                    <strong>{{ $trx->user_type }}</strong>
                                </td>
                                <td data-label="@lang('Trx')">
                                    <strong>{{ $trx->trx }}</strong>
                                </td>
                                <td data-label="@lang('Transacted')">
                                    {{ showDateTime($trx->created_at) }}<br>{{ diffForHumans($trx->created_at) }}
                                </td>

                                <td data-label="@lang('Amount')" class="budget">
                                    <span class="font-weight-bold @if($trx->trx_type == '+')text-success @else text-danger @endif">
                                        {{ $trx->trx_type }} {{showAmount($trx->amount,$general->currency)}} {{$trx->currency->currency_code}}
                                    </span>
                                </td>

                                <td data-label="@lang('Post Balance')" class="budget">
                                   {{ showAmount($trx->post_balance,$general->currency) }} {{$trx->currency->currency_code}}
                               </td>


                               <td data-label="@lang('Detail')">{{ __($trx->details) }} {{$trx->receiver ? @$trx->receiver->username : ''  }}</td>
                           </tr>
                           @empty
                           <tr>
                            <td class="text-muted text-center" colspan="100%">{{ __($emptyMessage) }}</td>
                        </tr>
                        @endforelse

                    </tbody>
                </table><!-- table end -->
            </div>
        </div>
        <div class="card-footer py-4">
            {{ paginateLinks($transactions) }}
        </div>
    </div><!-- card end -->
</div>
</div>

@endsection


@push('breadcrumb-plugins')
@if(request()->routeIs('admin.users.transactions'))
<form action="" method="GET" class="form-inline float-sm-right bg--white">
    <div class="input-group has_append">
        <input type="text" name="search" class="form-control" placeholder="@lang('TRX / Username')" value="{{ $search ?? '' }}">
        <div class="input-group-append">
            <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
        </div>
    </div>
</form>
@else
<form action="{{ route('admin.report.transaction.search') }}" method="GET" class="form-inline float-sm-right bg--white">
    <div class="input-group has_append">
        <input type="text" name="search" class="form-control" placeholder="@lang('TRX / Username')" value="{{ $search ?? '' }}">
        <div class="input-group-append">
            <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
        </div>
    </div>
</form>
@endif
@endpush


