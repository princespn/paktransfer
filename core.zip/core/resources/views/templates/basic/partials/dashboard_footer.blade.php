
<footer class="footer-section">
    <div class="footer-section__bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <p>{{date('Y')}} © {{$general->sitename}}. @lang('All Right Reserved')</p>
                </div>
            </div>
        </div>
    </div>
</footer>