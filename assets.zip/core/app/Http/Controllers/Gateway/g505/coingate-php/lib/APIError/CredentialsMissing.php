<?php

namespace CoinGate\APIError;

# HTTP Status 400
class CredentialsMissing extends BadRequest
{
}
