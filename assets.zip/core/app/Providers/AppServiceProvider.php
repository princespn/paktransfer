<?php

namespace App\Providers;

use App\Frontend;
use App\GeneralSetting;
use App\Language;
use App\Plugin;
use App\Wallet;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Auth;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Schema::defaultStringLength(191);

        $viewShare['general'] = GeneralSetting::first();
        $viewShare['socials'] = Frontend::where('data_keys','social.item')->get();
        $viewShare['shortAbout'] = Frontend::where('data_keys','homecontent')->first();
        $viewShare['menus'] = Frontend::where('data_keys','menu')->get();
        $viewShare['company_policy'] = Frontend::where('data_keys','company_policy')->get();
        $viewShare['plugins'] = Plugin::all();
        $viewShare['lan'] = Language::all();
        $viewShare['plugins'] = Plugin::all();
        view()->share($viewShare);

        view()->composer('partials.seo', function ($view) {
            $seo = \App\Frontend::where('data_keys', 'seo')->first();
            $view->with([
                'seo' => $seo ? $seo->data_values : $seo,
            ]);
        });


        view()->composer(activeTemplate().'partials.myWallet', function ($view) {
            if (Auth::check()) {
                 $myWallet = Wallet::where('user_id', Auth::id())->whereHas('currency', function ($gate) {
            $gate->where('status', 1);
        })->with('currency')->get();


                $view->with([
                    'myWallet' => $myWallet,
                ]);
            }
        });


        view()->composer('admin.partials.sidenav', function ($view) {
            $view->with([
                'banned_users_count'           => \App\User::banned()->count(),
                'email_unverified_users_count' => \App\User::emailUnverified()->count(),
                'sms_unverified_users_count'   => \App\User::smsUnverified()->count(),
                'pending_withdrawals_count'    => \App\Withdrawal::pending()->count(),
                'pending_deposits_count'    => \App\Deposit::where('status',2)->count(),
            ]);
        });
    }
}
