<?php

use Illuminate\Http\Request;

Route::middleware('auth:api')->get('/user', function () {
   return request()->user();
});
