<div class="row justify-content-end">
    <div class="col-xl-8">
        <div class="essen-btns">
            <a href="<?php echo e(route('user.transferIncoming')); ?>" class="<?php if(Request::routeIs('user.transferIncoming')): ?> active <?php endif; ?>"><i class="fa fa-arrow-down"></i><?php echo app('translator')->get('Received'); ?></a>
            <a href="<?php echo e(route('user.transferOutgoing')); ?>" class="<?php if(Request::routeIs('user.transferOutgoing')): ?> active <?php endif; ?>"><i class="fa fa-arrow-up"></i><?php echo app('translator')->get('Sent'); ?></a>
            <a href="<?php echo e(route('user.moneyTransfer')); ?>" class="<?php if(Request::routeIs('user.moneyTransfer')): ?> active <?php endif; ?>"><i class="fa fa-paper-plane"></i><?php echo app('translator')->get('Send Now'); ?></a>
        </div>
    </div>
</div>
<?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/transfer/nav.blade.php ENDPATH**/ ?>