<div class="col-md-3 ">
    <div class="dashboard-content">
        <div class="row text-white">
            <?php $__currentLoopData = $myWallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-12">
                    <a href="<?php echo e(route('user.currencyTrx',strtolower($data->currency->code))); ?>" class="text-white">
                    <div class="dashboard-w2 slice border-radius-5">
                        <div class="details">
                            <p class="amount mb-2 font-weight-bold"><?php echo e(__($data->currency->name)); ?></p>
                            <h6 class="mb-3">  <?php echo e(formatter_money($data->amount)); ?> <?php echo e(__($data->currency->code)); ?></h6>
                        </div>
                        <div class="icon">

                            <img src="<?php echo e(get_image(config('constants.logoIcon.path') .'/favicon.png')); ?>" class="wallet-cls" alt="*">
                        </div>
                    </div>
                    </a>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/partials/myWallet.blade.php ENDPATH**/ ?>