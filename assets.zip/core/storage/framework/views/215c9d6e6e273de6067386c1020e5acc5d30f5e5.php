<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>

    <!--Dashboard area-->
    <section class="section-padding blog-area">
        <div class="container">
            <div class="row">
               <?php echo $__env->make(activeTemplate().'partials.myWallet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-md-9">
                    <div class="dashboard-content">
                        <div class="dashboard-inner-content">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title float-left m-0"><?php echo app('translator')->get('Most Recent Transaction'); ?></h5>
                                    <a href="<?php echo e(route('user.transaction')); ?>" class="btn  btn-sqr float-right"><i
                                            class="fas fa-th"></i></a>
                                </div>
                                <div class="card-body p-0">

                                    <div class="accordion" id="accordionExample">

                                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="card">
                                                <div class="t-log-title ">
                                                    <div data-toggle="collapse" data-target="#collapse<?php echo e($data->id); ?>"
                                                         aria-expanded="true" aria-controls="collapse<?php echo e($data->id); ?>">
                                                        <div class="row align-items-center justify-content-between">
                                                            <div class="col-2 col-sm-3 col-md-1">
                                                                <div class="date-site">
                                                                    <span
                                                                        class="d-block"><?php echo e(date('M', strtotime($data->created_at))); ?></span>
                                                                    <span
                                                                        class="d-block"><?php echo e(date('d', strtotime($data->created_at))); ?></span>
                                                                </div>
                                                            </div>
                                                            <div class="col-6 col-sm-6 col-md-7">
                                                                <p><?php echo e(__($data->remark)); ?></p>
                                                                <p><?php echo e(__($data->title)); ?></p>
                                                            </div>
                                                            <div class="col-4 col-sm-3 col-md-3">
                                                                <div
                                                                    class="trans-amnt <?php if($data->type == '-'): ?>text-danger <?php else: ?> text-success <?php endif; ?>">
                                                                    <?php if($data->type == '-'): ?>- <?php else: ?>
                                                                        + <?php endif; ?> <?php echo e(formatter_money($data->amount)); ?> <?php echo e($data->currency->code); ?>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div id="collapse<?php echo e($data->id); ?>" class="collapse"
                                                     aria-labelledby="heading<?php echo e($data->id); ?>"
                                                     data-parent="#accordionExample">
                                                    <div class="card-body pad-15">
                                                        <div class="row">
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p><?php echo e($data->remark); ?>:</p>
                                                            </div>
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p>
                                                                    <strong><?php echo e(formatter_money($data->amount)); ?> <?php echo e($data->currency->code); ?></strong>
                                                                </p>
                                                            </div>
                                                            <div class="col col-sm-4 col-md-4">
                                                                <strong><?php echo app('translator')->get('Transaction ID'); ?>:</strong>
                                                                <small><?php echo e($data->trx); ?></small>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p><?php echo app('translator')->get('Charge'); ?>:</p>
                                                            </div>
                                                            <div class="col col-sm-6 col-md-6">
                                                                <p>
                                                                    <strong><?php echo e(formatter_money($data->charge)); ?> <?php echo e($data->currency->code); ?></strong>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p><?php echo app('translator')->get('Remaining Balance'); ?>:</p>
                                                            </div>
                                                            <div class="col col-sm-6 col-md-6">
                                                                <p>
                                                                    <strong><?php echo e(formatter_money($data->main_amo)); ?>  <?php echo e($data->currency->code); ?></strong>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p><?php echo app('translator')->get('Details'); ?>:</p>
                                                            </div>
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p><?php echo e($data->title); ?></p>
                                                            </div>
                                                            <div class="col col-sm-4 col-md-4">
                                                                <p><small class="mr-2"><i
                                                                            class="fa fa-calendar-o"></i> <?php echo e(date(' d M, Y ', strtotime($data->created_at))); ?>

                                                                    </small> <small><i
                                                                            class="fa fa-clock-o"></i> <?php echo e(date('H:i A ', strtotime($data->created_at))); ?>

                                                                    </small></p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section><!--/Dashboard area-->


<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>