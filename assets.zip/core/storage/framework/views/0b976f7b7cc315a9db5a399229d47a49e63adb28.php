<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('import-css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--Dashboard area-->
    <section class="section-padding gray-bg blog-area">
        <div class="container">
            <div class="row dashboard-content">


                <div class="col-md-12">
                    <div class="dashboard-inner-content">

                        <div class="row">
                            <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="col-lg-3 col-md-4 mb-4">
                                <div class="card bg-white">
                                    <h5 class="card-header text-center"><?php echo e(__($data->name)); ?></h5>
                                    <div class="card-body">
                                        <img src="<?php echo e(get_image(config('constants.deposit.gateway.path').'/'. $data->image)); ?>" class="card-img-top" alt="<?php echo e($data->name); ?>">
                                    </div>
                                    <div class="card-footer bg-white">
                                        <a href="javascript:void(0)"  data-id="<?php echo e($data->id); ?>" data-resource="<?php echo e($data); ?>"
                                            data-min_amount="<?php echo e(formatter_money($data->min_amount, $data->method->crypto())); ?>"
                                            data-max_amount="<?php echo e(formatter_money($data->max_amount, $data->method->crypto())); ?>"
                                            data-base_symbol="<?php echo e($data->baseSymbol()); ?>"
                                            data-fix_charge="<?php echo e(formatter_money($data->fixed_charge, $data->method->crypto())); ?>"
                                            data-percent_charge="<?php echo e(formatter_money($data->percent_charge, $data->method->crypto())); ?>" class="custom-btn btn btn-block deposit" data-toggle="modal" data-target="#exampleModal">
                                            <?php echo app('translator')->get('Deposit Now'); ?></a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/Dashboard area-->


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title method-name" id="exampleModalLabel">Modal title</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('user.deposit.insert')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p class="text-danger depositLimit"></p>
                        <p class="text-danger depositCharge"></p>

                        <div class="form-group">
                            <input type="hidden" name="currency" class="edit-currency" value="">
                            <input type="hidden" name="method_code" class="edit-method-code" value="">
                        </div>


                        <div class="form-group">
                            <label><?php echo app('translator')->get('Select Wallet'); ?> :</label>
                            <select name="currency_id" id="currency_id" class="form-control form-control-lg">
                                <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e(__($data->code)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label><?php echo app('translator')->get('Enter Amount'); ?>:</label>
                            <div class="input-group">
                                <input id="amount" type="text" class="form-control form-control-lg" onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')" name="amount" placeholder="0.00" required=""  value="<?php echo e(old('amount')); ?>">

                                <div class="input-group-prepend">
                                    <span class="input-group-text currency-addon"><?php echo app('translator')->get('CNY'); ?></span>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn-primary"><?php echo app('translator')->get('Confirm'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script>

        $(document).ready(function(){
            $('.deposit').on('click', function () {

                var id = $(this).data('id');
                var result = $(this).data('resource');
                var minAmount = $(this).data('min_amount');
                var maxAmount = $(this).data('max_amount');
                var baseSymbol = $(this).data('base_symbol');
                var fixCharge = $(this).data('fix_charge');
                var percentCharge = $(this).data('percent_charge');

                var depositLimit = `<?php echo app('translator')->get('Deposit Limit'); ?>: ${minAmount} - ${maxAmount}  ${baseSymbol}`;
                $('.depositLimit').text(depositLimit);
                var depositCharge = `<?php echo app('translator')->get('Charge'); ?>: ${fixCharge} ${baseSymbol} + ${percentCharge} %`
                $('.depositCharge').text(depositCharge);
                $('.method-name').text(`<?php echo app('translator')->get('Payment By'); ?> ${result.name}`);
                $('.currency-addon').text(`${result.currency}`);
                

                $('.edit-currency').val(result.currency);
                $('.edit-method-code').val(result.method_code);

            })
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/payment/deposit.blade.php ENDPATH**/ ?>