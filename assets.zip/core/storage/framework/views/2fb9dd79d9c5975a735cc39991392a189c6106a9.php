<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="<?php echo e(get_image(config('constants.logoIcon.path') .'/favicon.png')); ?>" type="image/x-icon">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(get_image(config('constants.logoIcon.path') .'/favicon.png')); ?>"/>
    <title><?php echo e($general->sitename); ?> | <?php echo e(($page_title) ? $page_title : ''); ?> </title>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link href="<?php echo e(asset('assets/template/basic/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('import-css'); ?>

    <?php echo $__env->yieldPushContent('style-lib'); ?>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"/>
    <link href="<?php echo e(asset('assets/template/basic/css/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/template/basic/css/themify-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/template/basic/css/nice-select.css')); ?>" rel="stylesheet">
    <?php echo $__env->make('partials.notify-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/template/basic/css/style.php')); ?>?color=<?php echo e($general->bclr); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
<!--Header Area-->
<header class="header-area">
    <nav class="navbar navbar-expand-xl main-menu">
        <div class="container-fluid">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(get_image(config('constants.logoIcon.path') .'/logo.png')); ?>" class="d-inline-block align-top" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="menu-toggle"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav m-auto">
                    <li class="nav-item <?php if(Request::routeIs('home')): ?> active <?php endif; ?>"><a class="nav-link" href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>



                    <li class="nav-item ">
                        <?php if(Request::routeIs('home')): ?>
                        <a href="#about" class="nav-link"> <?php echo app('translator')->get("About"); ?></a>
                        <?php else: ?>
                        <a href="<?php echo e(route('home')); ?>#about" class="nav-link"> <?php echo app('translator')->get("About"); ?></a>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item ">
                        <?php if(Request::routeIs('home')): ?>
                        <a href="#how-it-work" class="nav-link"> <?php echo app('translator')->get("How It Work"); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('home')); ?>#how-it-work" class="nav-link"> <?php echo app('translator')->get("How It Work"); ?></a>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item ">
                        <?php if(Request::routeIs('home')): ?>
                        <a href="#services" class="nav-link"> <?php echo app('translator')->get("Services"); ?></a>
                        <?php else: ?>
                         <a href="<?php echo e(route('home')); ?>#services" class="nav-link"> <?php echo app('translator')->get("Services"); ?></a>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item ">
                        <?php if(Request::routeIs('home')): ?>
                            <a href="#why-choose-us" class="nav-link"> <?php echo app('translator')->get("Why Choose Us"); ?></a>
                        <?php else: ?>
                            <a href="<?php echo e(route('home')); ?>#why-choose-us" class="nav-link"> <?php echo app('translator')->get("Why Choose Us"); ?></a>
                        <?php endif; ?>
                    </li>



                    <li class="nav-item <?php if(Request::routeIs('home.announce')): ?> active <?php endif; ?>">
                        <a href="<?php echo e(route('home.announce')); ?>" class="nav-link"><?php echo app('translator')->get("Announcement"); ?></a>
                    </li>


                    <?php if(count($menus) > 0): ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo app('translator')->get('Menu'); ?></a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('home.menu',[$data->id, str_slug($data->value->title)])); ?>"><?php echo e($data->value->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item <?php if(Request::routeIs('home.contact')): ?> active <?php endif; ?>"><a href="<?php echo e(route('home.contact')); ?>" class="nav-link "><?php echo app('translator')->get("Contact"); ?></a></li>
                </ul>


                <?php if($general->language_status == 1): ?>
                <select class="custom-select-2 sources" id="langSel" placeholder="En">
                    <?php $__currentLoopData = $lan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?> ><i class="flag-icon flag-icon-es"></i><?php echo e(__($item->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php endif; ?>

                <div class="header-btn justify-content-end">
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('user.home')); ?>" class="bttn-small btn-emt"><?php echo app('translator')->get('Dashboard'); ?></a>
                    <?php endif; ?>
                    <?php if(auth()->guard()->guest()): ?>
                        <a href="<?php echo e(route('user.login')); ?>" class="bttn-small btn-emt"><?php echo app('translator')->get('Account'); ?></a>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </nav>
</header><!--/Header Area-->


<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('templates.basic.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('assets/template/basic/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/jquery-migrate.js')); ?>"></script>

<script src="<?php echo e(asset('assets/template/basic/js/popper.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/bootstrap.min.js')); ?>"></script>
<?php echo $__env->yieldContent('import-js'); ?>

<script src="<?php echo e(asset('assets/template/basic/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/parallax.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/template/basic/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/jquery.counterup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/scrollUp.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/template/basic/js/particles.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/particle-app.js')); ?>"></script>
<script src="<?php echo e(asset('assets/template/basic/js/jquery.nice-select.min.js')); ?>"></script>

<?php echo $__env->make('partials.notify-js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $(document).on("click", ".custom-option", function() {
        window.location.href = "<?php echo e(url('/')); ?>/change-lang/"+$(this).data('value') ;

    });
    $(".custom-select-2").each(function () {
        var classes = $(this).attr("class"),
            selected = $(this).find(':selected').text();

        var template = '<div class="' + classes + '">';
        template += '<span class="custom-select-trigger">' + selected + '</span>';
        template += '<div class="custom-options">';
        $(this).find("option").each(function () {
            template += '<span class="custom-option ' + $(this).attr("class") + '" data-value="' + $(this).attr("value") + '">' + $(this).html() + '</span>';
        });
        template += '</div></div>';

        $(this).wrap('<div class="custom-select-wrapper"></div>');
        $(this).hide();
        $(this).after(template);
    });



</script>

<?php echo $__env->yieldPushContent('js'); ?>
<script src="<?php echo e(asset('assets/template/basic/js/script.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>







</body>
</html>
<?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/layouts/master.blade.php ENDPATH**/ ?>