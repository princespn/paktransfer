<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>

    <!--Dashboard area-->
    <section class="section-padding gray-bg">
        <div class="container">
            <div class="row">


                <?php echo $__env->make(activeTemplate().'partials.myWallet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="col-md-9">
                    <div class="dashboard-content" id="app">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12" >
                                <div class="dashboard-inner-content">
                                    <div class="card">
                                        <h5 class="card-header"><?php echo app('translator')->get('Send Money'); ?></h5>
                                        <div class="card-body bg-white">

                                            <?php echo $__env->make(activeTemplate().'user.transfer.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                                            <form action="#" method="post" accept-charset="utf-8">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" v-bind:value="protection" name="protection">
                                                <div class="row">
                                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                                        <label for="a-trans"><?php echo app('translator')->get('Amount Transfer'); ?></label>
                                                        <input type="text" class="amount" id="amount"  name="amount" value="<?php echo e(old('amount')); ?>" v-model="amount" v-on:keyup.enter="amountCalc" v-on:change="amountCalc"
                                                               onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')"
                                                               placeholder="0.00">
                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                                        <label class="currency"><?php echo app('translator')->get('Currency'); ?></label>
                                                        <select name="currency" id="currency" class="form-control form-control-lg" v-on:change="changeCurrency">
                                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($data->id); ?>" data-resource="<?php echo e($data); ?>"><?php echo e($data->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>

                                                    </div>

                                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                                        <label for="charge"><?php echo app('translator')->get('Charge'); ?>: <small
                                                            class="money_transfer_charge"><?php echo e($money_transfer->percent_charge); ?> %  + {{currencyMoneyTransferFixCharge}} {{selectCurrency.code}} </small></label>
                                                        <input type="text" class="form-control sum" v-model="sum" name="sum" value="<?php echo e(old('sum')); ?>" readonly>
                                                    </div>
                                                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-6">
                                                        <label><?php echo app('translator')->get('Receiver Username / E-mail /Phone'); ?></label>
                                                        <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Receiver Username / Email /Phone'); ?>" id="receiver" value="<?php echo e(old('receiver')); ?>"
                                                               name="receiver" v-model="receiver"  v-on:change="getReceiver">

                                                        <div v-html="message"></div>

                                                    </div>
                                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-6">
                                                        <br>
                                                        <button type="button"  v-bind:class="[protection ? 'bg-success' : 'site-bg']"  class="mt-2 custom-btn" data-toggle="collapse" data-target="#protect" aria-expanded="false" aria-controls="protect"><span v-if="protection == true"><?php echo app('translator')->get('Protected'); ?></span> <span v-else> <?php echo app('translator')->get('Protection'); ?></span></button>
                                                    </div>
                                                    <div class="col-12">
                                                        <div class="collapse " id="protect" aria-expanded="false">
                                                            <div class="card text-white card-body site-bg ash-bg-3">



                                                                <label><?php echo app('translator')->get('Code protection'); ?></label>
                                                                <input type="text" class="form-control" name="code_protect" v-model="code_protect"
                                                                    onkeyup="this.value = this.value.replace (/^\.|[^\d\.]/g, '')"
                                                                    placeholder="Enter Four Digit Numeric Code" maxlength="4" value="<?php echo e(old('code_protect')); ?>">

                                                                <div v-html="messageCode"></div>

                                                                <small class="form-text text-white">
                                                                    <?php echo app('translator')->get("Transaction will be performed when the recipient enters the protection code. Send the protection code to the recipient when you make sure the deal is completed."); ?>
                                                                </small>



                                                                <div class="card-footer">

                                                                    <div class="row justify-content-end">
                                                                        <div class="col-12 text-right">
                                                                            <button type="button" class="custom-btn protect-button"  @click="changeProtection" > <span v-if="protection == false"> <i class="fa fa-lock"></i> <?php echo app('translator')->get('Protect Now'); ?></span> <span v-else> <i class="fa fa-unlock"></i> <?php echo app('translator')->get('Remove Protection'); ?></span></button>
                                                                        </div>
                                                                    </div>
                                                                </div>


                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 mt-3">
                                                        <label for="textarea"><?php echo app('translator')->get('Note for recipient'); ?></label>
                                                        <textarea class="form-control" rows="5" name="note"><?php echo e(old('note')); ?></textarea>
                                                    </div>

                                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 mt-3">
                                                        <button class="custom-btn" type="submit" v-if="sendMoney"><?php echo app('translator')->get('Send money'); ?></button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section><!--/Dashboard area-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script src="<?php echo e(asset('assets/admin/js/axios.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/vue.js')); ?>"></script>

    <script>
        var app = new Vue({
            el: "#app",
            data:{
                amount: 0,
                sum: 0,

                moneyTransferPercentCharge : "<?php echo e($money_transfer->percent_charge); ?>",
                moneyTransferFixCharge : "<?php echo e($money_transfer->fix_charge); ?>",
                currencyMoneyTransferFixCharge : null,
                receiver: '',
                message: `<p class="text-info"><?php echo app('translator')->get("User must be registered in the system"); ?></p>`,
                messageCode: '',
                code_protect:null,
                protection: false,
                sendMoney: false,
                validUser: false,
                selectCurrency:{
                    id: null,
                    name: null,
                    code: null,
                    rate: null,
                }

            },

            mounted(){
                this.getReceiver();
                this.amountCalc();
                this.changeCurrency();

            },
            methods: {
                changeCurrency() {
                    var x = $("#currency option:selected").data('resource');
                    this.selectCurrency.id = x.id;
                    this.selectCurrency.name = x.name;
                    this.selectCurrency.code = x.code;
                    this.selectCurrency.rate = parseFloat(x.rate);
                    this.currencyMoneyTransferFixCharge = (this.moneyTransferFixCharge * parseFloat(x.rate)).toFixed(2);
                    this.amountCalc();
                },

                amountCalc(){
                    var _this = this;
                    var percentCharge = (this.amount * parseFloat(this.moneyTransferPercentCharge))/100;
                    var percentFix = parseFloat(percentCharge) + parseFloat(this.moneyTransferFixCharge*this.selectCurrency.rate);
                    if(_this.amount > 0){
                        _this.sum = percentFix.toFixed(2);
                    }else {
                        _this.sum = 0;
                    }

                    if(_this.validUser == true && _this.amount > 0){

                        _this.sendMoney =  true
                    }else {
                        _this.sendMoney =  false
                    }
                },

                changeProtection(){
                    if(this.protection ==  false){
                         this.protection = true;
                        $('.collapse').collapse('hide');
                    }else if(this.protection ==  true){
                         this.protection = false;
                        $('.collapse').collapse('hide');
                    }
                    return this.protection;
                },

                getReceiver(e){
                    var _this = this;
                    var username = this.receiver;
                    if (username.length > 0) {
                        axios.post("<?php echo e(route('check.valid.user')); ?>", {
                            username,
                            _token: "<?php echo e(csrf_token()); ?>"
                        })
                            .then(function (response) {
                                var output = response.data;

                                if(output.result == 'error'){
                                    _this.message = `<p class="text-danger">"${_this.receiver}" is not valid to send money</p>`;
                                    _this.sendMoney =  false
                                }else{
                                    _this.message = `<p class="text-success">"${_this.receiver}" is a valid user to send money </p>`;
                                    _this.validUser = true;
                                    if(_this.amount > 0){
                                        _this.sendMoney =  true
                                    }else {
                                        _this.sendMoney =  false
                                    }
                                }
                            })
                            .catch(function (error) {
                                console.log(error);
                            });
                    }else {
                        _this.message= `<p class="text-muted"><?php echo app('translator')->get("User must be registered in the system"); ?></p>`

                    }
                }
            }

        });
    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make(activeTemplate().'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/user/transfer/index.blade.php ENDPATH**/ ?>