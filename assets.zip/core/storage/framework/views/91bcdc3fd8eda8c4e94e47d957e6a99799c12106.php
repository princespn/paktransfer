<!--breadcrumb area-->
<section class="breadcrumb-area gradient-overlay">
    <div id="particles-js"></div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-8 col-md-12 col-sm-12 centered">
                <div class="banner-title">
                    <h2><?php echo e(__($page_title)); ?></h2>
                </div>
            </div>
        </div>
    </div>
</section><!--/breadcrumb area-->

<?php /**PATH /home/paktransfer/public_html/core/resources/views/templates/basic/partials/user-breadcrumb.blade.php ENDPATH**/ ?>