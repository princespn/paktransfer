<?php $__env->startSection('title','Home Content'); ?>
<?php $__env->startSection('content'); ?>

    <!--Hero Area-->
    <?php if(isset($homeContent)): ?>
    <section class="hero-section" style="background-image: url('<?php echo e(asset('assets/template/basic/images/')); ?>/map.jpg');">
        <div class="hero-area">
            <div id="particles-js"></div>
            <div class="single-hero">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-11 centered">
                            <div class="hero-sub">
                                <div class="table-cell">
                                    <div class="hero-left">
                                        <h4><?php echo e(__($homeContent->data_values->title)); ?></h4>
                                        <h1><?php echo e(__($homeContent->data_values->sub_title)); ?></h1>
                                        <p><?php echo app('translator')->get($homeContent->data_values->details); ?> </p>
                                        <a href="<?php echo e(route('user.register')); ?>" class="bttn-mid btn-fill"><i class="ti-user"></i><?php echo app('translator')->get('REGISTER'); ?></a>
                                        <a href="<?php echo e(route('user.login')); ?>" class="bttn-mid btn-emt"><i class="ti-key"></i><?php echo app('translator')->get('LOGIN'); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <!--/Hero Area-->


    <section id="about" class="about-area">
        <div class="about-content mid-bg-gray wow fadeInUp" data-wow-delay="0.4s">
            <div class="about-content-inner-2">
                <div class="section-title mb-10">
                    <h4><?php echo e(__(@$about->data_values->title)); ?></h4>
                    <h2><?php echo e(__($about->data_values->sub_title)); ?></h2>
                </div>
                <p>
                    <?php echo __($about->data_values->details) ?>
                </p>
            </div>
        </div>
        <div class="about-left wow fadeInUp section-padding" data-wow-delay="0.4s">
            <div class="left-img-wrap">
                <img src="<?php echo e(asset('assets/images/frontend/about/about.jpg')); ?>" alt="about" style="width: 100%;">
            </div>
        </div>
    </section>

    <!--feature Area-->
    <?php if(count($flowsteps)>0): ?>
        <section id="how-it-work" class="feature-area section-padding-2 work gradient-overlay" style="background-image: url(<?php echo e(get_image(config('constants.frontend.bgimage.path') .'/'. 'work_bg_img.jpg')); ?>); position:relative">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 centered wow fadeInUp" data-wow-delay="0.3s">
                        <div class="section-title cl-white">
                            <h2><?php echo e(__($flowstep_caption->data_values->title)); ?></h2>
                            <p><?php echo e(__($flowstep_caption->data_values->short_details)); ?></p>
                        </div>
                    </div>
                </div>

                <?php $__currentLoopData = $flowsteps->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i =>$flowstep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="row justify-content-center">

                        <?php $__currentLoopData = $flowstep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 wow fadeInUp" data-wow-delay="0.3s">
                                <div class="single-feature-2 <?php if($loop->first): ?> bottom-after <?php elseif($loop->last): ?> <?php else: ?> bottom-before <?php endif; ?>">
                                    <?php echo $data->data_values->icon ?>
                                    <h4><?php echo e(__($data->data_values->title)); ?></h4>
                                    <p><?php echo e(__($data->data_values->details)); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
    <!--/feature Area-->



    <!--Section-->
    <?php if(count($whychooses)>0): ?>
    <section id="services" class="section-padding-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 centered">
                    <div class="section-title">
                        <h2><?php echo e(__($whychoose_caption->data_values->title)); ?></h2>
                        <p><?php echo e(__($whychoose_caption->data_values->short_details)); ?></p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center centered">
                <?php $__currentLoopData = $whychooses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-sm-8">
                    <div class="single-box">
                     <?php echo $data->data_values->icon;  ?>
                        <h3><?php echo e(__($data->data_values->title)); ?></h3>
                        <p><?php echo e(__($data->data_values->sub_title)); ?></p>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <!--/Section-->

    <!-- Team Area -->
    <section  class="team-area gradient-overlay section-padding-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6 centered wow fadeInUp" data-wow-delay="0.3s">
                    <div class="section-title cl-white">
                        <h4><?php echo e(__($team_caption->data_values->title)); ?></h4>
                        <h2><?php echo e(__($team_caption->data_values->short_details)); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="single-team-4">
                            <img src="<?php echo e(get_image(config('constants.frontend.team.path').'/'.$data->data_values->image)); ?>" alt="<?php echo e(__($data->data_values->name)); ?>">
                            <div class="team-content cl-black">
                                <h4><?php echo e(__($data->data_values->name)); ?></h4>
                                <p><?php echo e(__($data->data_values->designation)); ?></p>
                                <div class="social">
                                    <?php if(!empty($data->data_values->facebook)): ?>
                                        <a href="<?php echo e($data->data_values->facebook); ?>" class="cl-facebook"> <i class="fab fa-facebook-f"></i></a>
                                    <?php endif; ?>

                                    <?php if(!empty($data->data_values->twitter)): ?>
                                        <a href="<?php echo e($data->data_values->twitter); ?>" class="cl-twitter"><i class="fab fa-twitter"></i></a>
                                    <?php endif; ?>

                                    <?php if(!empty($data->data_values->linkedin)): ?>
                                        <a href="<?php echo e($data->data_values->linkedin); ?>" class="cl-linkedin"><i class="fab fa-linkedin"></i></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section><!-- /Team Area -->




    <!-- How it works Area -->
    <?php if(count($howitworks)>0): ?>


    <section id="why-choose-us" class="section-padding-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-7 centered">
                    <div class="section-title">
                        <h2><?php echo e(__($howitwork_caption->data_values->title)); ?></h2>
                        <p><?php echo e(__($howitwork_caption->data_values->short_details)); ?></p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center centered">
                <?php $__currentLoopData = $howitworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-6 col-sm-10 col-lg-4 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="single-box">
                            <?php echo $data->data_values->icon;  ?>
                            <h3><?php echo e(__($data->data_values->title)); ?></h3>
                            <p><?php echo e(__($data->data_values->sub_title)); ?></p>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


    <?php endif; ?>
    <!-- /How it works Area -->



    <!-- Review Area -->
    <?php if(count($testimonials)>0): ?>
    <section id="testimonial" class="review-area section-padding gradient-overlay cl-white">
        <div class="container">

            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-6 centered wow fadeInUp" data-wow-delay="0.3s">
                    <div class="section-title">
                        <h2><?php echo e(__($testimonial_caption->data_values->title)); ?></h2>
                        <p><?php echo e(__($testimonial_caption->data_values->short_details)); ?></p>
                    </div>
                </div>
            </div>

            <div class="row justify-content-center">
                <div class="col-12 wow fadeInUp" data-wow-delay="0.4s">

                    <div class="testimonials owl-carousel">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="single-review">
                                <div class="reviewer-thumb">
                                    <img src="<?php echo e(get_image(config('constants.frontend.testimonial.path').'/'.$data->data_values->image)); ?>" alt="<?php echo e(__($data->data_values->author)); ?>">
                                    <h3><?php echo e(__($data->data_values->author)); ?></h3>
                                    <span><?php echo e(__($data->data_values->designation)); ?></span>
                                </div>
                                <p><?php echo e(__($data->data_values->quote)); ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <!-- /Review Area -->


    <!-- Section -->
    <section class="section-padding">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-sm-12 wow fadeInRight" data-wow-delay="0.4s">
                    <div class="faq-contents">
                        <ul class="accordion">
                            <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="javascript:void(0)"><i class="far fa-hand-point-right"></i> <?php echo e(__($data->data_values->title)); ?></a>
                                    <p><?php echo strip_tags($data->data_values->body) ?></p>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section><!-- /Section -->





    <!--We Accept Brands Area-->
    <section class=" section-padding pm gradient-overlay cl-white"  style="background-image: url(<?php echo e(get_image(config('constants.frontend.bgimage.path') .'/'. 'pm_bg_img.jpg')); ?>)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 centered">
                    <div class="section-title">
                        <h2><?php echo app('translator')->get('Payment We Accept'); ?></h2>
                    </div>
                </div>
            </div>
            <div class="owl-theme owl-carousel payment-slider">
                <?php $__currentLoopData = $weAccept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-brands">
                    <a href="javascript:void(0)" title="<?php echo e(__($data->name)); ?>"><img src="<?php echo e(get_image(config('constants.deposit.gateway.path') .'/'. $data->image)); ?>" alt="<?php echo e($data->name); ?>"></a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>


        </div>
    </section><!--/Brands Area-->


    <!--Blog Area-->
    <?php if(count($blogs)>0): ?>
    <section class="blog-area section-padding-2">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-8 centered wow fadeInUp" data-wow-delay="0.3s">
                    <div class="section-title">
                        <h4><?php echo app('translator')->get('Announcement'); ?></h4>
                        <h2><?php echo app('translator')->get('Recent Announcement'); ?></h2>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="single-blog-2">
                        <div class="single-blog-img">
                            <img src="<?php echo e(get_image(config('constants.frontend.blog.post.path').'/'.$data->data_values->image)); ?>" alt="<?php echo e($data->data_values->title); ?>">
                            <a href="<?php echo e(route('home.announce.details',[$data->id, str_slug($data->data_values->title)])); ?>"><i class="fas fa-expand"></i></a>
                        </div>
                        <div class="single-blog-content">
                            <div class="blog-meta">
                                <span><a href=""><i class="far fa-calendar-alt"></i><?php echo e(date('d M Y', strtotime($data->created_at))); ?></a></span>
                            </div>
                            <h3><a href="<?php echo e(route('home.announce.details',[$data->id, str_slug($data->data_values->title)])); ?>"><?php echo e(__($data->data_values->title)); ?></a></h3>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <!--/Blog Area-->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('import-css'); ?>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"/>
<?php $__env->stopSection(); ?>


<?php echo $__env->make(activeTemplate().'layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\tsk_update\kbzaman\done\xenwallet\core\resources\views/templates/basic/home.blade.php ENDPATH**/ ?>